/*
 kpoint.cpp

 Copyright (c) 2014, 2015, 2016 Terumasa Tadano

 This file is distributed under the terms of the MIT license.
 Please see the file 'LICENCE.txt' in the root directory 
 or http://opensource.org/licenses/mit-license.php for information.
*/

#include "mpi_common.h" 
#include "kpoint.h"
#include "memory.h"
#include "error.h"
#include "system.h"
#include "phonon_dos.h"
#include "symmetry_core.h"
#include "dynamical.h"
#include "timer.h"
#include <iostream>
#include <iomanip>
#include <cmath>
#include <set>
#include <map>
#include <numeric>
#include "parsephon.h"
#include "relaxation.h"
#include "mathfunctions.h"

#ifdef _USE_BOOST
#include <boost/lexical_cast.hpp>
#endif

#ifdef _USE_EIGEN
#include <Eigen/Core>
#include <Eigen/LU>
#endif

using namespace PHON_NS;

Kpoint::Kpoint(PHON *phon): Pointers(phon) {}

Kpoint::~Kpoint()
{
    if (kpoint_mode < 3) {
        memory->deallocate(xk);
        memory->deallocate(kvec_na);

        if (kpoint_mode == 2) {
            memory->deallocate(knum_minus);
        }

        if (kpoint_mode == 1) {
            if (mympi->my_rank == 0) memory->deallocate(kaxis);
        }
    }
}

void Kpoint::kpoint_setups(std::string mode)
{
    symmetry->symmetry_flag = true;

    unsigned int i, j;
    std::string str_tmp;

    MPI_Bcast(&kpoint_mode, 1, MPI_INT, 0, MPI_COMM_WORLD);

    if (mympi->my_rank == 0) {

        std::cout << " k points" << std::endl;
        std::cout << " ========" << std::endl << std::endl;

    }

    switch (kpoint_mode) {
    case 0:

        if (mympi->my_rank == 0) {
            std::cout << "  KPMODE = 0 : Calculation on given k points" << std::endl;
        }

        setup_kpoint_given(kpInp, nk, xk, kvec_na);

        if (mympi->my_rank == 0) {
            std::cout << "  Number of k points : " << nk << std::endl << std::endl;
            std::cout << "  List of k points : " << std::endl;
            for (i = 0; i < nk; ++i) {
                std::cout << std::setw(5) << i + 1 << ":";
                for (j = 0; j < 3; ++j) {
                    std::cout << std::setw(15) << xk[i][j];
                }
                std::cout << std::endl;
            }
            std::cout << std::endl;
        }

        break;

    case 1:

        if (mympi->my_rank == 0) {
            std::cout << "  KPMODE = 1: Band structure calculation" << std::endl;
        }

        setup_kpoint_band(kpInp, nk, xk, kvec_na, kaxis);

        if (mympi->my_rank == 0) {
            std::cout << "  Number of paths : " << kpInp.size() << std::endl << std::endl;
            std::cout << "  List of k paths : " << std::endl;

            for (i = 0; i < kpInp.size(); ++i) {
                std::cout << std::setw(4) << i + 1 << ":";
                std::cout << std::setw(3) << kpInp[i].kpelem[0];
                std::cout << " (";
                for (int k = 0; k < 3; ++k) {
                    std::cout << std::setprecision(4) << std::setw(8)
                        << std::atof((kpInp[i].kpelem[k + 1]).c_str());
                }
                std::cout << ")";
                std::cout << std::setw(3) << kpInp[i].kpelem[4];
                std::cout << " (";
                for (int k = 0; k < 3; ++k) {
                    std::cout << std::setprecision(4) << std::setw(8)
                        << std::atof((kpInp[i].kpelem[k + 5]).c_str());
                }
                std::cout << ")";
                std::cout << std::setw(4) << kpInp[i].kpelem[8] << std::endl;
            }
            std::cout << std::endl;
            std::cout << "  Number of k points : " << nk << std::endl << std::endl;

        }

        break;

    case 2:

        if (mympi->my_rank == 0) {
            std::cout << "  KPMODE = 2: Uniform grid" << std::endl;
        }

        setup_kpoint_mesh(kpInp, nk, nkx, nky, nkz, xk,
                          kvec_na, symmetry->symmetry_flag, kpoint_irred_all);

        nk_reduced = kpoint_irred_all.size();

        weight_k.clear();
        for (i = 0; i < kpoint_irred_all.size(); ++i) {
            weight_k.push_back(static_cast<double>(kpoint_irred_all[i].size()) / static_cast<double>(nk));
        }

        if (mympi->my_rank == 0) {
            std::cout << "  Gamma-centered uniform grid with the following mesh density: " << std::endl;
            std::cout << "  nk1:" << std::setw(4) << nkx << std::endl;
            std::cout << "  nk2:" << std::setw(4) << nky << std::endl;
            std::cout << "  nk3:" << std::setw(4) << nkz << std::endl;
            std::cout << std::endl;
            std::cout << "  Number of k points : " << nk << std::endl;
            std::cout << "  Number of irreducible k points : " << kpoint_irred_all.size() << std::endl << std::endl;
            std::cout << "  List of irreducible k points (reciprocal coordinate, weight) : " << std::endl;

            for (i = 0; i < kpoint_irred_all.size(); ++i) {
                std::cout << "  " << std::setw(5) << i + 1 << ":";
                for (j = 0; j < 3; ++j) {
                    std::cout << std::setprecision(5) << std::setw(14)
                        << std::scientific << kpoint_irred_all[i][0].kval[j];
                }
                std::cout << std::setprecision(6) << std::setw(11)
                    << std::fixed << weight_k[i] << std::endl;
            }
            std::cout << std::endl;
        }

        memory->allocate(knum_minus, nk);
        gen_nkminus(nk, knum_minus, xk);

        for (i = 0; i < nk_reduced; ++i) {
            for (j = 0; j < kpoint_irred_all[i].size(); ++j) {
                kmap_to_irreducible.insert(std::map<int, int>::value_type(kpoint_irred_all[i][j].knum, i));
            }
        }

        break;

    case 3:

        if (mympi->my_rank == 0) {
            std::cout << "  KPMODE = 3: Momentum-resolved final state amplitude" << std::endl;
        }

        setup_kpoint_plane(kpInp, nplanes, kp_planes);

        if (mympi->my_rank == 0) {
            std::cout << "  Number of planes : " << nplanes << std::endl;
            for (i = 0; i < nplanes; ++i) {
                std::cout << "  The number of k points in plane " << std::setw(3) << i + 1 << " :" ;
                std::cout << std::setw(8) << kp_planes[i].size() << std::endl;
            }
            std::cout << std::endl;
        }

        break;

    default:
        error->exit("read_kpoints", "This cannot happen.");
    }
}

void Kpoint::setup_kpoint_given(std::vector<KpointInp> &kpinfo,
                                unsigned int &n,
                                double **&k,
                                double **&kdirec)
{
    int i, j;
    double norm;

    n = kpinfo.size();
    MPI_Bcast(&n, 1, MPI_UNSIGNED, 0, MPI_COMM_WORLD);

    memory->allocate(k, n, 3);
    memory->allocate(kdirec, n, 3);

    if (mympi->my_rank == 0) {
        j = 0;
        for (std::vector<KpointInp>::const_iterator it = kpinfo.begin(); it != kpinfo.end(); ++it) {
            for (i = 0; i < 3; ++i) {
#ifdef _USE_BOOST
                k[j][i] = boost::lexical_cast<double>((*it).kpelem[i]);
#else
                k[j][i] = std::atof(((*it).kpelem[i]).c_str());
#endif 
            }

            rotvec(kdirec[j], k[j], system->rlavec_p, 'T');

            norm = kdirec[j][0] * kdirec[j][0]
                + kdirec[j][1] * kdirec[j][1]
                + kdirec[j][2] * kdirec[j][2];

            if (norm > eps) {
                for (i = 0; i < 3; ++i) kdirec[j][i] /= std::sqrt(norm);
            }

            ++j;
        }
    }

    MPI_Bcast(&k[0][0], 3 * n, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(&kdirec[0][0], 3 * n, MPI_DOUBLE, 0, MPI_COMM_WORLD);
}

void Kpoint::setup_kpoint_band(std::vector<KpointInp> &kpinfo,
                               unsigned int &n,
                               double **&xk,
                               double **&kdirec,
                               double *&axis)
{
    int i, j, k;


    if (mympi->my_rank == 0) {

        unsigned int npath;
        std::string **kp_symbol;
        unsigned int *nk_path;
        double **k_start, **k_end;

        npath = kpinfo.size();

        memory->allocate(kp_symbol, npath, 2);
        memory->allocate(k_start, npath, 3);
        memory->allocate(k_end, npath, 3);
        memory->allocate(nk_path, npath);

        n = 0;
        i = 0;
        for (std::vector<KpointInp>::const_iterator it = kpinfo.begin(); it != kpinfo.end(); ++it) {
            kp_symbol[i][0] = (*it).kpelem[0];
            kp_symbol[i][1] = (*it).kpelem[4];
#ifdef _USE_BOOST
            for (j = 0; j < 3; ++j) {
                k_start[i][j] = boost::lexical_cast<double>((*it).kpelem[j + 1]);
                k_end[i][j] = boost::lexical_cast<double>((*it).kpelem[j + 5]);
            }
            nkp[i] = boost::lexical_cast<int>((*it).kpelem[8]);
#else
            for (j = 0; j < 3; ++j) {
                k_start[i][j] = std::atof(((*it).kpelem[j + 1]).c_str());
                k_end[i][j] = std::atof(((*it).kpelem[j + 5]).c_str());

            }
            nk_path[i] = std::atoi(((*it).kpelem[8]).c_str());
#endif
            n += nk_path[i];
            ++i;
        }

        memory->allocate(xk, n, 3);
        memory->allocate(kdirec, n, 3);
        memory->allocate(axis, n);

        unsigned int ik = 0;
        double norm;
        double direc_tmp[3], tmp[3];

        for (i = 0; i < npath; ++i) {
            for (j = 0; j < 3; ++j) {
                direc_tmp[j] = k_end[i][j] - k_start[i][j];
            }

            rotvec(direc_tmp, direc_tmp, system->rlavec_p, 'T');
            norm = std::pow(direc_tmp[0], 2)
                + std::pow(direc_tmp[1], 2)
                + std::pow(direc_tmp[2], 2);
            norm = std::sqrt(norm);

            if (norm > eps) {
                for (j = 0; j < 3; ++j) direc_tmp[j] /= norm;
            }

            for (j = 0; j < nk_path[i]; ++j) {
                for (k = 0; k < 3; ++k) {
                    xk[ik][k] = k_start[i][k]
                        + (k_end[i][k] - k_start[i][k])
                        * static_cast<double>(j) / static_cast<double>(nk_path[i] - 1);

                    kdirec[ik][k] = direc_tmp[k];
                }

                if (ik == 0) {
                    axis[ik] = 0.0;
                } else {
                    if (j == 0) {
                        axis[ik] = axis[ik - 1];
                    } else {
                        for (k = 0; k < 3; ++k) tmp[k] = xk[ik][k] - xk[ik - 1][k];
                        rotvec(tmp, tmp, system->rlavec_p, 'T');
                        axis[ik] = axis[ik - 1]
                            + std::sqrt(tmp[0] * tmp[0]
                                + tmp[1] * tmp[1]
                                + tmp[2] * tmp[2]);
                    }
                }
                ++ik;
            }
        }
        memory->deallocate(nk_path);
        memory->deallocate(k_start);
        memory->deallocate(k_end);
        memory->deallocate(kp_symbol);
    }

    MPI_Bcast(&n, 1, MPI_UNSIGNED, 0, MPI_COMM_WORLD);

    if (mympi->my_rank > 0) {
        memory->allocate(xk, n, 3);
        memory->allocate(kdirec, n, 3);
    }

    MPI_Bcast(&xk[0][0], 3 * n, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(&kdirec[0][0], 3 * n, MPI_DOUBLE, 0, MPI_COMM_WORLD);
}

void PHON_NS::Kpoint::setup_kpoint_mesh(std::vector<KpointInp> &kpinfo,
                                        unsigned int &nk,
                                        unsigned int &nkx,
                                        unsigned int &nky,
                                        unsigned int &nkz,
                                        double **&xk,
                                        double **&kdirec,
                                        const bool usesym,
                                        std::vector<std::vector<KpointList> > &kp_irreducible)
{
    int i, j;
    unsigned int nk_tmp[3];
    double norm;

    if (mympi->my_rank == 0) {

#ifdef _USE_BOOST
        nkx = boost::lexical_cast<int>(kpinfo[0].kpelem[0]);
        nky = boost::lexical_cast<int>(kpinfo[0].kpelem[1]);
        nkz = boost::lexical_cast<int>(kpinfo[0].kpelem[2]);
#else 
        nkx = std::atoi((kpinfo[0].kpelem[0]).c_str());
        nky = std::atoi((kpinfo[0].kpelem[1]).c_str());
        nkz = std::atoi((kpinfo[0].kpelem[2]).c_str());
#endif
        nk = nkx * nky * nkz;

        memory->allocate(xk, nk, 3);
        memory->allocate(kdirec, nk, 3);

        nk_tmp[0] = nkx;
        nk_tmp[1] = nky;
        nk_tmp[2] = nkz;

        gen_kmesh(usesym, nk_tmp, xk, kp_irreducible);

        for (i = 0; i < nk; ++i) {
            for (j = 0; j < 3; ++j) kdirec[i][j] = xk[i][j];

            rotvec(kdirec[i], kdirec[i], system->rlavec_p, 'T');
            norm = kdirec[i][0] * kdirec[i][0]
                + kdirec[i][1] * kdirec[i][1]
                + kdirec[i][2] * kdirec[i][2];

            if (norm > eps) {
                for (j = 0; j < 3; ++j) kdirec[i][j] /= std::sqrt(norm);
            }
        }
    }

    MPI_Bcast(&nk, 1, MPI_UNSIGNED, 0, MPI_COMM_WORLD);
    MPI_Bcast(&nkx, 1, MPI_UNSIGNED, 0, MPI_COMM_WORLD);
    MPI_Bcast(&nky, 1, MPI_UNSIGNED, 0, MPI_COMM_WORLD);
    MPI_Bcast(&nkz, 1, MPI_UNSIGNED, 0, MPI_COMM_WORLD);

    if (mympi->my_rank > 0) {
        memory->allocate(xk, nk, 3);
        memory->allocate(kdirec, nk, 3);
    }

    MPI_Bcast(&xk[0][0], 3 * nk, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(&kdirec[0][0], 3 * nk, MPI_DOUBLE, 0, MPI_COMM_WORLD);

    mpi_broadcast_kpoint_vector(kp_irreducible);
}

void PHON_NS::Kpoint::mpi_broadcast_kpoint_vector(std::vector<std::vector<KpointList> > &kp_irreducible)
{
    int i, j, k, ik;
    double **xk_tmp;
    unsigned int *knum_tmp;
    unsigned int *kequiv_tmp;

    std::vector<KpointList> kp_group;
    std::vector<double> ktmp;

    // Broadcast kp_irredicible to all threads

    unsigned int nk_irred = kp_irreducible.size();
    MPI_Bcast(&nk_irred, 1, MPI_UNSIGNED, 0, MPI_COMM_WORLD);

    memory->allocate(xk_tmp, nk, 3);
    memory->allocate(knum_tmp, nk);
    memory->allocate(kequiv_tmp, nk_irred);

    if (mympi->my_rank == 0) {
        ik = 0;

        for (i = 0; i < nk_irred; ++i) {
            kequiv_tmp[i] = kp_irreducible[i].size();

            for (j = 0; j < kequiv_tmp[i]; ++j) {
                knum_tmp[ik] = kp_irreducible[i][j].knum;
                for (k = 0; k < 3; ++k) {
                    xk_tmp[ik][k] = kp_irreducible[i][j].kval[k];
                }
                ++ik;
            }
        }
    }

    MPI_Bcast(&knum_tmp[0], nk, MPI_UNSIGNED, 0, MPI_COMM_WORLD);
    MPI_Bcast(&kequiv_tmp[0], nk_irred, MPI_UNSIGNED, 0, MPI_COMM_WORLD);
    MPI_Bcast(&xk_tmp[0][0], 3 * nk, MPI_DOUBLE, 0, MPI_COMM_WORLD);


    if (mympi->my_rank > 0) {
        kp_irreducible.clear();
        kp_group.clear();

        ik = 0;

        for (i = 0; i < nk_irred; ++i) {
            kp_group.clear();
            for (j = 0; j < kequiv_tmp[i]; ++j) {
                ktmp.clear();
                ktmp.push_back(xk_tmp[ik][0]);
                ktmp.push_back(xk_tmp[ik][1]);
                ktmp.push_back(xk_tmp[ik][2]);
                kp_group.push_back(KpointList(knum_tmp[ik], ktmp));
                ++ik;
            }
            kp_irreducible.push_back(kp_group);
        }
    }

    memory->deallocate(xk_tmp);
    memory->deallocate(knum_tmp);
    memory->deallocate(kequiv_tmp);
}

void PHON_NS::Kpoint::mpi_broadcast_kplane_vector(const unsigned int nplane,
                                                  std::vector<KpointPlane> *&kp_plane)
{
    int i, j;
    int nkp;
    int **naxis;
    double **xk_plane;

    for (i = 0; i < nplane; ++i) {
        nkp = kp_plane[i].size();

        MPI_Bcast(&nkp, 1, MPI_INT, 0, MPI_COMM_WORLD);

        memory->allocate(naxis, nkp, 2);
        memory->allocate(xk_plane, nkp, 3);

        if (mympi->my_rank == 0) {
            for (j = 0; j < nkp; ++j) {
                naxis[j][0] = kp_plane[i][j].n[0];
                naxis[j][1] = kp_plane[i][j].n[1];
                xk_plane[j][0] = kp_plane[i][j].k[0];
                xk_plane[j][1] = kp_plane[i][j].k[1];
                xk_plane[j][2] = kp_plane[i][j].k[2];
            }
        }

        MPI_Bcast(&naxis[0][0], 2 * nkp, MPI_INT, 0, MPI_COMM_WORLD);
        MPI_Bcast(&xk_plane[0][0], 3 * nkp, MPI_DOUBLE, 0, MPI_COMM_WORLD);

        if (mympi->my_rank > 0) {
            for (j = 0; j < nkp; ++j) {
                kp_plane[i].push_back(KpointPlane(xk_plane[j], naxis[j]));
            }
        }
        memory->deallocate(naxis);
        memory->deallocate(xk_plane);
    }
}


void Kpoint::setup_kpoint_plane(std::vector<KpointInp> &kpinfo,
                                unsigned int &nplane,
                                std::vector<KpointPlane> *&kp_plane)
{
    nplane = kpinfo.size();
    MPI_Bcast(&nplane, 1, MPI_UNSIGNED, 0, MPI_COMM_WORLD);

    memory->allocate(kp_plane, nplane);
    memory->allocate(kp_planes_tri, nplane);

    if (mympi->my_rank == 0) {
        gen_kpoints_plane(kpinfo, kp_plane, kp_planes_tri);

        //        for (i = 0; i < nplane; ++i) {
        //            for (std::vector<KpointPlaneTriangle>::const_iterator it = kp_planes_tri[i].begin(); it != kp_planes_tri[i].end(); ++it) {
        //                std::cout << (*it).index << std::endl;
        //                std::cout << (*it).xk1[0] << " " << (*it).xk1[1] << " " << (*it).xk1[2] << std::endl;
        //                std::cout << (*it).xk2[0] << " " << (*it).xk2[1] << " " << (*it).xk2[2] << std::endl;
        //                std::cout << (*it).xk3[0] << " " << (*it).xk3[1] << " " << (*it).xk3[2] << std::endl;
        //                std::cout << (*it).inside_FBZ << std::endl;
        //            }
        //        }
    }

    mpi_broadcast_kplane_vector(nplane, kp_plane);
}


void Kpoint::gen_kmesh(const bool usesym,
                       const unsigned int nk_in[3],
                       double **xk_out,
                       std::vector<std::vector<KpointList> > &kplist_out)
{
    unsigned int ix, iy, iz;
    unsigned int i, ik;
    double **xkr;

    unsigned int nk_tot = nk_in[0] * nk_in[1] * nk_in[2];
    int nsym;


    memory->allocate(xkr, nk_tot, 3);

    for (ix = 0; ix < nk_in[0]; ++ix) {
        for (iy = 0; iy < nk_in[1]; ++iy) {
            for (iz = 0; iz < nk_in[2]; ++iz) {
                ik = iz + iy * nk_in[2] + ix * nk_in[2] * nk_in[1];
                xkr[ik][0] = static_cast<double>(ix) / static_cast<double>(nk_in[0]);
                xkr[ik][1] = static_cast<double>(iy) / static_cast<double>(nk_in[1]);
                xkr[ik][2] = static_cast<double>(iz) / static_cast<double>(nk_in[2]);
            }
        }
    }

    if (usesym) {
        nsym = symmetry->SymmList.size();
    } else {
        nsym = 1;
    }
    reduce_kpoints(nsym, xkr, nk_in, kplist_out);

    for (ik = 0; ik < nk_tot; ++ik) {
        for (i = 0; i < 3; ++i) {
            xk_out[ik][i] = xkr[ik][i] - static_cast<double>(nint(xkr[ik][i]));
        }
    }

    memory->deallocate(xkr);
}

void Kpoint::reduce_kpoints(const unsigned int nsym,
                            double **xkr,
                            const unsigned int nk_in[3],
                            std::vector<std::vector<KpointList> > &kplist_out)
{
    unsigned int ik;
    unsigned int i, j;
    int nloc, isym;
    unsigned int nk_tot;

    bool *k_found;

    std::vector<KpointList> k_group;
    std::vector<double> ktmp;

    double srot[3][3];
    double xk_sym[3], xk_orig[3];
    double srot_inv[3][3], srot_inv_t[3][3];

    double ***symop_k;

    memory->allocate(symop_k, nsym, 3, 3);

    for (isym = 0; isym < nsym; ++isym) {

        for (i = 0; i < 3; ++i) {
            for (j = 0; j < 3; ++j) {
                srot[i][j] = static_cast<double>(symmetry->SymmList[isym].rot[i][j]);
            }
        }


        invmat3(srot_inv, srot);
        transpose3(srot_inv_t, srot_inv);

        for (i = 0; i < 3; ++i) {
            for (j = 0; j < 3; ++j) {
                symop_k[isym][i][j] = srot_inv_t[i][j];
            }
        }
    }

    kplist_out.clear();

    nk_tot = nk_in[0] * nk_in[1] * nk_in[2];
    memory->allocate(k_found, nk_tot);

    for (ik = 0; ik < nk_tot; ++ik) k_found[ik] = false;

    for (ik = 0; ik < nk_tot; ++ik) {

        if (k_found[ik]) continue;

        k_group.clear();

        for (i = 0; i < 3; ++i) xk_orig[i] = xkr[ik][i];

        for (isym = 0; isym < nsym; ++isym) {

            rotvec(xk_sym, xk_orig, symop_k[isym]);

            for (i = 0; i < 3; ++i) xk_sym[i] = xk_sym[i] - nint(xk_sym[i]);

            //            nloc = get_knum(xk_sym[0], xk_sym[1], xk_sym[2]);

            nloc = get_knum(xk_sym, nk_in);


            if (nloc == -1) {

                error->exit("reduce_kpoints", "Cannot find the kpoint");

            } else {

                if (!k_found[nloc]) {
                    k_found[nloc] = true;
                    ktmp.clear();
                    ktmp.push_back(xk_sym[0]);
                    ktmp.push_back(xk_sym[1]);
                    ktmp.push_back(xk_sym[2]);

                    k_group.push_back(KpointList(nloc, ktmp));
                }

            }

            // Time-reversal symmetry

            if (symmetry->time_reversal_sym) {

                for (i = 0; i < 3; ++i) xk_sym[i] *= -1.0;
                //                nloc = get_knum(xk_sym[0], xk_sym[1], xk_sym[2]);
                nloc = get_knum(xk_sym, nk_in);

                if (nloc == -1) {

                    error->exit("reduce_kpoints", "Cannot find the kpoint");

                } else {

                    if (!k_found[nloc]) {
                        k_found[nloc] = true;
                        ktmp.clear();
                        ktmp.push_back(xk_sym[0]);
                        ktmp.push_back(xk_sym[1]);
                        ktmp.push_back(xk_sym[2]);

                        k_group.push_back(KpointList(nloc, ktmp));
                    }
                }
            }
        }
        kplist_out.push_back(k_group);
    }

    memory->deallocate(k_found);
    memory->deallocate(symop_k);
}

void Kpoint::gen_kpoints_plane(std::vector<KpointInp> kplist,
                               std::vector<KpointPlane> *kpout,
                               std::vector<KpointPlaneTriangle> *kpout_tri)
{
    int i, j;
    int nplane = kplist.size();

    int N1, N2;
    int ik1, ik2;

    int number_of_tiles, number_of_triangle_tiles;
    int **triangle;

    double frac1, frac2;
    double xk_tmp[3];
    double xk0[3], xk1[3], xk2[3], xk3[3];
    double **xk;
    double dprod, norm1, norm2, costheta;
    int n_in[2];
    int m;
    int n1, n2, n3, n4;
    bool is_inside_FBZ;
    int itri;

    for (i = 0; i < nplane; ++i) {
        N1 = std::atoi(kplist[i].kpelem[3].c_str());
        N2 = std::atoi(kplist[i].kpelem[7].c_str());

        n_in[0] = N1;
        n_in[1] = N2;

        frac1 = 1.0 / static_cast<double>(N1 - 1);
        frac2 = 1.0 / static_cast<double>(N2 - 1);

        for (j = 0; j < 3; ++j) {
            xk0[j] = 0.0;
            xk1[j] = std::atof(kplist[i].kpelem[j].c_str());
            xk2[j] = std::atof(kplist[i].kpelem[4 + j].c_str());
        }

        dprod = 0.0;
        norm1 = 0.0;
        norm2 = 0.0;

        for (j = 0; j < 3; ++j) {
            dprod += xk1[j] * xk2[j];
            norm1 += xk1[j] * xk1[j];
            norm2 += xk2[j] * xk2[j];
        }
        costheta = dprod / std::sqrt(norm1 * norm2);
        if (std::abs(std::abs(costheta) - 1.0) < eps12) {
            error->exit("gen_kpoints_plane",
                        "Two vectors have to be linearly independent with each other.");
        }

        kp_plane_geometry.push_back(KpointPlaneGeometry(xk0, xk1, xk2, n_in));

        for (ik1 = 0; ik1 < N1; ++ik1) {
            for (ik2 = 0; ik2 < N2; ++ik2) {

                for (j = 0; j < 3; ++j) {
                    xk_tmp[j] = static_cast<double>(ik1) * frac1 * xk1[j]
                        + static_cast<double>(ik2) * frac2 * xk2[j];
                }
                if (in_first_BZ(xk_tmp)) {
                    n_in[0] = ik1;
                    n_in[1] = ik2;
                    kpout[i].push_back(KpointPlane(xk_tmp, n_in));
                }
            }
        }

        memory->allocate(xk, N1 * N2, 3);

        m = 0;
        for (ik1 = 0; ik1 < N1; ++ik1) {
            for (ik2 = 0; ik2 < N2; ++ik2) {

                for (j = 0; j < 3; ++j) {
                    xk[m][j] = static_cast<double>(ik1) * frac1 * xk1[j]
                        + static_cast<double>(ik2) * frac2 * xk2[j];
                }
                ++m;
            }
        }

        number_of_tiles = (N1 - 1) * (N2 - 1);
        number_of_triangle_tiles = 2 * number_of_tiles;

        memory->allocate(triangle, number_of_triangle_tiles, 3);

        for (ik1 = 0; ik1 < N1 - 1; ++ik1) {
            for (ik2 = 0; ik2 < N2 - 1; ++ik2) {

                n1 = ik2 + ik1 * N2;
                n2 = ik2 + (ik1 + 1) * N2;
                n3 = (ik2 + 1) + ik1 * N2;
                n4 = (ik2 + 1) + (ik1 + 1) * N2;

                m = 2 * (ik2 + ik1 * (N2 - 1));

                triangle[m][0] = n1;
                triangle[m][1] = n2;
                triangle[m][2] = n4;

                ++m;

                triangle[m][0] = n1;
                triangle[m][1] = n3;
                triangle[m][2] = n4;

            }
        }

        for (itri = 0; itri < number_of_triangle_tiles; ++itri) {

            for (j = 0; j < 3; ++j) {
                xk1[j] = xk[triangle[itri][0]][j];
                xk2[j] = xk[triangle[itri][1]][j];
                xk3[j] = xk[triangle[itri][2]][j];
            }

            is_inside_FBZ = in_first_BZ(xk1) || in_first_BZ(xk2) || in_first_BZ(xk3);
            if (is_inside_FBZ) {
                kpout_tri[i].push_back(KpointPlaneTriangle(itri, triangle[itri]));
            }
        }

        memory->deallocate(xk);
        memory->deallocate(triangle);
    }
}

void Kpoint::gen_nkminus(const unsigned int nk,
                         unsigned int *minus_k,
                         double **xk_in)
{
    unsigned int ik;
    int ik_minus;

    for (ik = 0; ik < nk; ++ik) {

        ik_minus = get_knum(-xk[ik][0], -xk[ik][1], -xk[ik][2]);

        if (ik_minus == -1)
            error->exit("gen_nkminus",
                        "-xk doesn't exist on the mesh point.");
        if (ik_minus < ik) continue;

        minus_k[ik] = ik_minus;
        minus_k[ik_minus] = ik;
    }
}

int Kpoint::get_knum(const double kx,
                     const double ky,
                     const double kz)
{
    double diff[3];
    double dkx = static_cast<double>(nkx);
    double dky = static_cast<double>(nky);
    double dkz = static_cast<double>(nkz);

    diff[0] = static_cast<double>(nint(kx * dkx)) - kx * dkx;
    diff[1] = static_cast<double>(nint(ky * dky)) - ky * dky;
    diff[2] = static_cast<double>(nint(kz * dkz)) - kz * dkz;

    double norm =
        std::sqrt(diff[0] * diff[0]
            + diff[1] * diff[1]
            + diff[2] * diff[2]);

    if (norm >= eps12) {

        return -1;

    } else {

        int iloc, jloc, kloc;

        iloc = (nint(kx * dkx + 2.0 * dkx)) % nkx;
        jloc = (nint(ky * dky + 2.0 * dky)) % nky;
        kloc = (nint(kz * dkz + 2.0 * dkz)) % nkz;

        return kloc + nkz * jloc + nky * nkz * iloc;
    }
}

int Kpoint::get_knum(const double xk[3],
                     const unsigned int nk[3])
{
    int i;
    double diff[3];
    double dnk[3];
    double norm;

    for (i = 0; i < 3; ++i) dnk[i] = static_cast<double>(nk[i]);
    for (i = 0; i < 3; ++i) diff[i] = static_cast<double>(nint(xk[i] * dnk[i])) - xk[i] * dnk[i];

    norm = std::sqrt(diff[0] * diff[0]
        + diff[1] * diff[1]
        + diff[2] * diff[2]);

    if (norm >= eps12) {

        return -1;

    } else {

        int iloc, jloc, kloc;

        iloc = (nint(xk[0] * dnk[0] + 2.0 * dnk[0])) % nk[0];
        jloc = (nint(xk[1] * dnk[1] + 2.0 * dnk[1])) % nk[1];
        kloc = (nint(xk[2] * dnk[2] + 2.0 * dnk[2])) % nk[2];

        return kloc + nk[2] * jloc + nk[1] * nk[2] * iloc;
    }
}

bool Kpoint::in_first_BZ(double *xk_in)
{
    int i, j, k;
    int nmax = 1;
    double tmp[3];
    double dist, dist_min;
    int iloc;
    int ncount;

    bool ret;


    for (i = 0; i < 3; ++i) tmp[i] = xk_in[i];

    rotvec(tmp, tmp, system->rlavec_p, 'T');

    dist_min = std::sqrt(tmp[0] * tmp[0] + tmp[1] * tmp[1] + tmp[2] * tmp[2]);

    ncount = 0;

    iloc = ncount;

    for (i = -nmax; i <= nmax; ++i) {
        for (j = -nmax; j <= nmax; ++j) {
            for (k = -nmax; k <= nmax; ++k) {

                if (i == 0 && j == 0 && k == 0) continue;

                ++ncount;

                tmp[0] = xk_in[0] - static_cast<double>(i);
                tmp[1] = xk_in[1] - static_cast<double>(j);
                tmp[2] = xk_in[2] - static_cast<double>(k);

                rotvec(tmp, tmp, system->rlavec_p, 'T');
                dist = std::sqrt(tmp[0] * tmp[0] + tmp[1] * tmp[1] + tmp[2] * tmp[2]);

                if (dist < dist_min) {
                    iloc = ncount;
                    break;
                }
            }
        }
    }

    if (iloc == 0) {
        ret = true;
    } else {
        ret = false;
    }

    return ret;
}


void Kpoint::generate_irreducible_kmap(int *kequiv,
                                       unsigned int &nk_irreducible,
                                       std::vector<int> &k_irreducible,
                                       const unsigned int n1,
                                       const unsigned int n2,
                                       const unsigned int n3,
                                       double **xk_in,
                                       const int nsymop,
                                       int ***symrot)
{
    int i, j, k;
    int isym;
    int nktot = n1 * n2 * n3;
    int ksym;

    double xk_orig[3], xk_sym[3];
    double srot[3][3], srot_inv[3][3], srot_inv_t[3][3];

    for (i = 0; i < nktot; ++i) kequiv[i] = i;

    for (i = 0; i < nktot; ++i) {

        if (kequiv[i] < i) continue;

        for (j = 0; j < 3; ++j) xk_orig[j] = xk_in[i][j];

        for (isym = 0; isym < nsymop; ++isym) {

            for (j = 0; j < 3; ++j) {
                for (k = 0; k < 3; ++k) {
                    srot[j][k] = symrot[isym][j][k];
                }
            }

            invmat3(srot_inv, srot);
            transpose3(srot_inv_t, srot_inv);

            rotvec(xk_sym, xk_orig, srot_inv_t);

            ksym = get_knum(xk_sym[0], xk_sym[1], xk_sym[2]);

            if (ksym > kequiv[i]) {
                kequiv[ksym] = i;
            }
        }
    }

    nk_irreducible = 0;
    k_irreducible.clear();

    std::map<int, int> map_to_irreducible_index;

    for (i = 0; i < nktot; ++i) {
        if (kequiv[i] == i) {
            map_to_irreducible_index.insert(std::map<int, int>::value_type(i, nk_irreducible));
            ++nk_irreducible;
            k_irreducible.push_back(i);
        }
    }

    for (i = 0; i < nktot; ++i) {
        kequiv[i] = map_to_irreducible_index[kequiv[i]];
    }

    map_to_irreducible_index.clear();
}

