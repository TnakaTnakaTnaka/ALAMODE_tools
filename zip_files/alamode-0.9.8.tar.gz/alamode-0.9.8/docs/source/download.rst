Download
========

.. highlight:: bash


You can download the latest and previous versions of ALAMODE at http://sourceforge.net/projects/alamode .

You can also download the package from the git repository as

    $ git clone http://github.com/ttadano/alamode.git

If you choose the GitHub version, please use the 'master' branch.

