.. ALAMODE documentation master file, created by
   sphinx-quickstart on Wed Jun  4 17:36:19 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

ALAMODE
========


Users Guide
-----------

.. toctree::
   :maxdepth: 2

   intro
   download
   install
   quickstart
   tutorial
   input/inputalm
   input/inputanphon
   output
   formalism/formalism_alm.rst
   formalism/formalism_anphon.rst



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

